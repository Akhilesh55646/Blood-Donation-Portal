import { useState, useEffect } from "react";
import { MapPin, Clock, Star, Phone, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";

interface Center {
    _id: string;
    name: string;
    address: string;
    city: string;
    phone: string;
    hours: string;
    services: string[];
    rating: number;
    reviews: number;
    isOpen: boolean;
}

const Centers = () => {
    const { toast } = useToast();
    const [centers, setCenters] = useState<Center[]>([]);
    const [loading, setLoading] = useState(true);
    const [cityFilter, setCityFilter] = useState("");

    const fetchCenters = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (cityFilter) params.append("city", cityFilter);

            const response = await fetch(`http://localhost:5000/api/centers?${params}`);
            const data = await response.json();
            setCenters(data);
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to fetch centers",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCenters();
    }, []);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        fetchCenters();
    };

    const handleGetDirections = (address: string) => {
        const encodedAddress = encodeURIComponent(address);
        window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, "_blank");
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <Header />

            <main className="container py-8">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold mb-4">Donation Centers</h1>
                    <p className="text-gray-600 max-w-2xl mx-auto">
                        Find blood donation centers near you. Schedule your appointment and save lives.
                    </p>
                </div>

                {/* Search Form */}
                <form onSubmit={handleSearch} className="bg-white p-6 rounded-xl shadow-md mb-8">
                    <div className="flex gap-4">
                        <Input
                            placeholder="Search by city..."
                            value={cityFilter}
                            onChange={(e) => setCityFilter(e.target.value)}
                            className="flex-1"
                        />
                        <Button type="submit" disabled={loading}>
                            {loading ? "Searching..." : "Search"}
                        </Button>
                    </div>
                </form>

                {loading ? (
                    <div className="text-center py-16">
                        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                        <p>Loading centers...</p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {centers.map((center) => (
                            <Card key={center._id} className="hover:shadow-lg transition-shadow">
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <CardTitle className="text-xl">{center.name}</CardTitle>
                                        <Badge className={center.isOpen ? "bg-green-500" : "bg-gray-500"}>
                                            {center.isOpen ? "Open" : "Closed"}
                                        </Badge>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm">
                                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                        <span className="font-semibold">{center.rating}</span>
                                        <span className="text-gray-500">({center.reviews} reviews)</span>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        <div className="flex items-start gap-2 text-sm">
                                            <MapPin className="h-4 w-4 text-primary mt-0.5" />
                                            <div>
                                                <p className="font-medium">{center.address}</p>
                                                {center.city && <p className="text-gray-500">{center.city}</p>}
                                            </div>
                                        </div>
                                        {center.hours && (
                                            <div className="flex items-center gap-2 text-sm">
                                                <Clock className="h-4 w-4 text-primary" />
                                                <span>{center.hours}</span>
                                            </div>
                                        )}
                                        {center.phone && (
                                            <div className="flex items-center gap-2 text-sm">
                                                <Phone className="h-4 w-4 text-primary" />
                                                <a href={`tel:${center.phone}`} className="hover:text-primary">
                                                    {center.phone}
                                                </a>
                                            </div>
                                        )}
                                        {center.services && center.services.length > 0 && (
                                            <div>
                                                <p className="text-sm font-semibold mb-2">Services:</p>
                                                <div className="flex flex-wrap gap-2">
                                                    {center.services.map((service, idx) => (
                                                        <Badge key={idx} variant="secondary" className="text-xs">
                                                            {service}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                        <Button
                                            className="w-full"
                                            variant="outline"
                                            onClick={() => handleGetDirections(center.address)}
                                        >
                                            <Navigation className="mr-2 h-4 w-4" />
                                            Get Directions
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </main>

            <Footer />
        </div>
    );
};

export default Centers;
