const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");

dotenv.config();
const app = express();

// Allow frontend to connect from any localhost port during development
app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    // Allow all localhost origins
    if (origin.startsWith('http://localhost:')) {
      return callback(null, true);
    }
    callback(new Error('Not allowed by CORS'));
  }
}));
app.use(express.json());

// -------------------- MongoDB Connection --------------------
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB Connected ✅"))
  .catch(err => console.log("MongoDB Error:", err));

const SECRET_KEY = "secret123"; // For JWT (use environment variable in production)

// -------------------- Email Transporter --------------------
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Verify email transporter
transporter.verify((error, success) => {
  if (error) {
    console.log("Email transporter error:", error);
  } else {
    console.log("Email transporter ready ✅");
  }
});

// -------------------- Schemas --------------------
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  mobile: String,
  password: String,
  verified: { type: Boolean, default: false }
});

const otpSchema = new mongoose.Schema({
  email: { type: String, required: true },
  otp: { type: String, required: true },
  name: String,
  mobile: String,
  password: String,
  expiresAt: { type: Date, required: true },
  createdAt: { type: Date, default: Date.now }
});

const donorSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name: String,
  email: String,
  mobile: String,
  bloodGroup: String,
  location: String,
  lastDonation: Date,
  isAvailable: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

const emergencyRequestSchema = new mongoose.Schema({
  bloodType: { type: String, required: true },
  status: { type: String, enum: ['Critical', 'Urgent', 'High', 'Normal'], default: 'Normal' },
  location: String,
  hospital: String,
  unitsNeeded: { type: Number, default: 1 },
  contactName: String,
  contactPhone: String,
  message: String,
  responses: [{
    donorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    donorName: String,
    donorPhone: String,
    respondedAt: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true }
});

const centerSchema = new mongoose.Schema({
  name: String,
  address: String,
  city: String,
  phone: String,
  email: String,
  hours: String,
  services: [String],
  rating: { type: Number, default: 4.5 },
  reviews: { type: Number, default: 0 },
  isOpen: { type: Boolean, default: true },
  coordinates: {
    lat: Number,
    lng: Number
  }
});

const requestSchema = new mongoose.Schema({
  name: String,
  bloodGroup: String,
  contact: String,
  message: String,
});

const User = mongoose.model("User", userSchema);
const Otp = mongoose.model("Otp", otpSchema);
const Donor = mongoose.model("Donor", donorSchema);
const EmergencyRequest = mongoose.model("EmergencyRequest", emergencyRequestSchema);
const Center = mongoose.model("Center", centerSchema);
const Request = mongoose.model("Request", requestSchema);

// -------------------- Helper Functions --------------------
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
}

async function sendOTPEmail(email, otp, name) {
  const mailOptions = {
    from: `"DonateShareLife" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: '🔐 Your OTP for Registration - DonateShareLife',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, #e53e3e, #c53030); border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0;">❤️ DonateShareLife</h1>
        </div>
        <div style="padding: 30px; background: #f7fafc; border-radius: 0 0 10px 10px;">
          <h2 style="color: #2d3748;">Hello ${name}! 👋</h2>
          <p style="color: #4a5568; font-size: 16px;">Thank you for registering with DonateShareLife. Use the OTP below to verify your email address:</p>
          <div style="text-align: center; margin: 30px 0;">
            <div style="display: inline-block; padding: 15px 40px; background: #e53e3e; color: white; font-size: 32px; font-weight: bold; letter-spacing: 8px; border-radius: 10px;">
              ${otp}
            </div>
          </div>
          <p style="color: #718096; font-size: 14px;">⏰ This OTP is valid for <strong>5 minutes</strong> only.</p>
          <p style="color: #718096; font-size: 14px;">If you didn't request this OTP, please ignore this email.</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;">
          <p style="color: #a0aec0; font-size: 12px; text-align: center;">Join our community of life savers! ❤️</p>
        </div>
      </div>
    `
  };

  return transporter.sendMail(mailOptions);
}

// JWT Middleware
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    req.userId = decoded.id;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// -------------------- Routes --------------------

// ✅ Root route (for testing)
app.get("/", (req, res) => {
  res.send("Backend is running successfully!");
});

// Send OTP Route
app.post("/api/auth/send-otp", async (req, res) => {
  try {
    const { name, email, mobile, password } = req.body;

    // Validate required fields
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email and password are required" });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "Email already registered" });
    }

    // Generate OTP
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    // Hash password before storing
    const hashedPassword = await bcrypt.hash(password, 10);

    // Delete any existing OTP for this email
    await Otp.deleteMany({ email });

    // Save OTP with user data
    const otpDoc = new Otp({
      email,
      otp,
      name,
      mobile: mobile || "",
      password: hashedPassword,
      expiresAt
    });
    await otpDoc.save();

    // Send OTP email
    await sendOTPEmail(email, otp, name);

    res.json({ message: "OTP sent successfully to your email!" });
  } catch (error) {
    console.error("Send OTP Error:", error);
    res.status(500).json({ error: "Failed to send OTP. Please try again." });
  }
});

// Verify OTP and Complete Registration
app.post("/api/auth/verify-otp", async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ error: "Email and OTP are required" });
    }

    // Find OTP document
    const otpDoc = await Otp.findOne({ email });
    if (!otpDoc) {
      return res.status(400).json({ error: "OTP not found. Please request a new one." });
    }

    // Check if OTP expired
    if (new Date() > otpDoc.expiresAt) {
      await Otp.deleteOne({ email });
      return res.status(400).json({ error: "OTP expired. Please request a new one." });
    }

    // Verify OTP
    if (otpDoc.otp !== otp) {
      return res.status(400).json({ error: "Invalid OTP. Please try again." });
    }

    // Create verified user
    const user = new User({
      name: otpDoc.name,
      email: otpDoc.email,
      mobile: otpDoc.mobile,
      password: otpDoc.password,
      verified: true
    });
    await user.save();

    // Delete OTP document
    await Otp.deleteOne({ email });

    res.json({ message: "Email verified successfully! Registration complete." });
  } catch (error) {
    console.error("Verify OTP Error:", error);
    res.status(500).json({ error: "Verification failed. Please try again." });
  }
});

// Resend OTP Route
app.post("/api/auth/resend-otp", async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }

    // Find existing OTP document
    const existingOtp = await Otp.findOne({ email });
    if (!existingOtp) {
      return res.status(400).json({ error: "No pending registration found. Please start again." });
    }

    // Generate new OTP
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    // Update OTP
    existingOtp.otp = otp;
    existingOtp.expiresAt = expiresAt;
    await existingOtp.save();

    // Send new OTP email
    await sendOTPEmail(email, otp, existingOtp.name);

    res.json({ message: "New OTP sent successfully!" });
  } catch (error) {
    console.error("Resend OTP Error:", error);
    res.status(500).json({ error: "Failed to resend OTP. Please try again." });
  }
});

// Login Route
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid password" });

    if (!user.verified) return res.status(403).json({ error: "User not verified" });

    const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: "1d" });
    res.json({ token, name: user.name, email: user.email, userId: user._id });
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Get current user
app.get("/api/auth/me", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ==================== DONOR ROUTES ====================

// Get all donors OR search by blood group
app.get("/api/donors", async (req, res) => {
  try {
    const { bloodGroup, location } = req.query;
    let query = { isAvailable: true };

    if (bloodGroup) query.bloodGroup = bloodGroup;
    if (location) query.location = { $regex: location, $options: 'i' };

    const donors = await Donor.find(query).sort({ createdAt: -1 });
    res.json(donors);
  } catch (error) {
    console.error("Get Donors Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Register as donor
app.post("/api/donors", authMiddleware, async (req, res) => {
  try {
    const { bloodGroup, location } = req.body;
    const user = await User.findById(req.userId);

    if (!user) return res.status(404).json({ error: "User not found" });

    // Check if already registered as donor
    const existingDonor = await Donor.findOne({ userId: req.userId });
    if (existingDonor) {
      return res.status(400).json({ error: "You are already registered as a donor" });
    }

    const newDonor = new Donor({
      userId: req.userId,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      bloodGroup,
      location,
      isAvailable: true
    });
    await newDonor.save();
    res.json({ message: "Registered as donor successfully!", donor: newDonor });
  } catch (error) {
    console.error("Add Donor Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Update donor availability
app.patch("/api/donors/availability", authMiddleware, async (req, res) => {
  try {
    const { isAvailable } = req.body;
    const donor = await Donor.findOneAndUpdate(
      { userId: req.userId },
      { isAvailable },
      { new: true }
    );
    if (!donor) return res.status(404).json({ error: "Donor profile not found" });
    res.json({ message: "Availability updated", donor });
  } catch (error) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ==================== EMERGENCY REQUEST ROUTES ====================

// Get all emergency requests
app.get("/api/emergency-requests", async (req, res) => {
  try {
    const { bloodType, status } = req.query;
    let query = { isActive: true };

    if (bloodType) query.bloodType = bloodType;
    if (status) query.status = status;

    const requests = await EmergencyRequest.find(query).sort({ createdAt: -1 });
    res.json(requests);
  } catch (error) {
    console.error("Get Emergency Requests Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Create emergency request
app.post("/api/emergency-requests", async (req, res) => {
  try {
    const { bloodType, status, location, hospital, unitsNeeded, contactName, contactPhone, message } = req.body;

    if (!bloodType || !contactPhone) {
      return res.status(400).json({ error: "Blood type and contact phone are required" });
    }

    const newRequest = new EmergencyRequest({
      bloodType,
      status: status || 'Urgent',
      location,
      hospital,
      unitsNeeded: unitsNeeded || 1,
      contactName,
      contactPhone,
      message
    });
    await newRequest.save();
    res.json({ message: "Emergency request created!", request: newRequest });
  } catch (error) {
    console.error("Create Emergency Request Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Respond to emergency request
app.post("/api/emergency-requests/:id/respond", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    const request = await EmergencyRequest.findById(req.params.id);
    if (!request) return res.status(404).json({ error: "Request not found" });

    // Check if already responded
    const alreadyResponded = request.responses.some(r => r.donorId?.toString() === req.userId);
    if (alreadyResponded) {
      return res.status(400).json({ error: "You have already responded to this request" });
    }

    request.responses.push({
      donorId: req.userId,
      donorName: user.name,
      donorPhone: user.mobile || req.body.phone
    });
    await request.save();

    res.json({ message: "Thank you for responding! The requester will contact you soon.", request });
  } catch (error) {
    console.error("Respond to Request Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ==================== DONATION CENTERS ROUTES ====================

// Get all centers
app.get("/api/centers", async (req, res) => {
  try {
    const { city } = req.query;
    let query = {};
    if (city) query.city = { $regex: city, $options: 'i' };

    const centers = await Center.find(query).sort({ rating: -1 });

    // If no centers in DB, return sample data
    if (centers.length === 0) {
      return res.json([
        {
          _id: '1',
          name: 'Central Blood Bank',
          address: '123 Main Street, Downtown',
          city: 'Delhi',
          phone: '+91 98765 43210',
          hours: '8:00 AM - 8:00 PM',
          services: ['Whole Blood', 'Plasma', 'Platelets'],
          rating: 4.8,
          reviews: 156,
          isOpen: true
        },
        {
          _id: '2',
          name: 'Community Health Center',
          address: '456 Oak Avenue, Midtown',
          city: 'Delhi',
          phone: '+91 98765 43211',
          hours: '9:00 AM - 6:00 PM',
          services: ['Whole Blood', 'Plasma'],
          rating: 4.6,
          reviews: 89,
          isOpen: true
        },
        {
          _id: '3',
          name: 'University Medical Center',
          address: '789 Campus Drive, University District',
          city: 'Delhi',
          phone: '+91 98765 43212',
          hours: '7:00 AM - 9:00 PM',
          services: ['Whole Blood', 'Plasma', 'Platelets', 'Research'],
          rating: 4.9,
          reviews: 203,
          isOpen: true
        }
      ]);
    }

    res.json(centers);
  } catch (error) {
    console.error("Get Centers Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Add center (admin)
app.post("/api/centers", async (req, res) => {
  try {
    const newCenter = new Center(req.body);
    await newCenter.save();
    res.json({ message: "Center added successfully!", center: newCenter });
  } catch (error) {
    console.error("Add Center Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ==================== ELIGIBILITY CHECK ====================

app.post("/api/eligibility", (req, res) => {
  try {
    const { age, weight, recentTravel, recentSurgery, healthConditions, lastDonation } = req.body;

    let eligible = true;
    let reasons = [];

    // Age check (18-65)
    if (age < 18) {
      eligible = false;
      reasons.push("Must be at least 18 years old");
    } else if (age > 65) {
      eligible = false;
      reasons.push("Maximum age is 65 years");
    }

    // Weight check (min 50kg)
    if (weight < 50) {
      eligible = false;
      reasons.push("Must weigh at least 50kg");
    }

    // Recent travel to high-risk areas
    if (recentTravel) {
      eligible = false;
      reasons.push("Recent travel to high-risk areas may affect eligibility");
    }

    // Recent surgery
    if (recentSurgery) {
      eligible = false;
      reasons.push("Recent surgery requires a waiting period");
    }

    // Health conditions
    if (healthConditions && healthConditions.length > 0) {
      eligible = false;
      reasons.push("Some health conditions may affect eligibility");
    }

    // Last donation (must be 56 days apart)
    if (lastDonation) {
      const daysSinceLastDonation = Math.floor((Date.now() - new Date(lastDonation)) / (1000 * 60 * 60 * 24));
      if (daysSinceLastDonation < 56) {
        eligible = false;
        reasons.push(`Must wait ${56 - daysSinceLastDonation} more days since last donation`);
      }
    }

    res.json({
      eligible,
      reasons,
      message: eligible ? "You are eligible to donate blood!" : "You may not be eligible at this time"
    });
  } catch (error) {
    console.error("Eligibility Check Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Legacy Request Blood Route
app.post("/api/requests", async (req, res) => {
  try {
    const newRequest = new Request(req.body);
    await newRequest.save();
    res.json({ message: "Blood request submitted!" });
  } catch (error) {
    console.error("Request Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// -------------------- Start Server --------------------
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on PORT ${PORT}`));
