import { AlertCircle, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

const emergencyRequests = [
  {
    bloodType: "O-",
    status: "Critical",
    time: "5 minutes ago",
    location: "City Hospital",
    distance: "2.3 km",
    units: 3,
    variant: "destructive" as const,
  },
  {
    bloodType: "A+",
    status: "Urgent",
    time: "12 minutes ago",
    location: "Medical Center",
    distance: "4.1 km",
    units: 2,
    variant: "default" as const,
  },
  {
    bloodType: "B-",
    status: "High",
    time: "25 minutes ago",
    location: "Emergency Clinic",
    distance: "6.8 km",
    units: 1,
    variant: "secondary" as const,
  },
];

export const EmergencyRequests = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container">
        <div className="flex items-center gap-3 mb-4">
          <AlertCircle className="h-8 w-8 text-destructive" />
          <h2 className="text-3xl font-bold">Emergency Blood Requests</h2>
        </div>
        <p className="text-muted-foreground mb-8">
          Critical situations need immediate response. Your donation could save a life today.
        </p>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          {emergencyRequests.map((request, index) => (
            <Card key={index} className="border-l-4 border-l-destructive hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-4xl font-bold">{request.bloodType}</CardTitle>
                  <Badge variant={request.variant}>{request.status}</Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {request.time}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span className="font-medium">{request.location}</span>
                    <span className="text-muted-foreground">{request.distance}</span>
                  </div>
                  <div className="text-sm">
                    <span className="font-semibold">Units needed:</span> {request.units}
                  </div>
                  <Link to="/emergency">
                    <Button className="w-full" size="sm">
                      Respond
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link to="/emergency">
            <Button variant="outline" size="lg">
              View All Emergency Requests
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};
