const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String },
  blood_group: { type: String },
  location: {
    lat: Number,
    lng: Number
  },
  role: { type: String, enum: ["donor", "receiver", "admin"], default: "donor" },
  verified: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model("User", UserSchema);