import { useState, useEffect } from "react";
import { AlertCircle, MapPin, Clock, Phone, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";

interface EmergencyRequest {
    _id: string;
    bloodType: string;
    status: string;
    location: string;
    hospital: string;
    unitsNeeded: number;
    contactName: string;
    contactPhone: string;
    message: string;
    createdAt: string;
    responses: any[];
}

const Emergency = () => {
    const { toast } = useToast();
    const [requests, setRequests] = useState<EmergencyRequest[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchRequests = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/emergency-requests");
            const data = await response.json();
            setRequests(data);
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to fetch emergency requests",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRequests();
    }, []);

    const handleRespond = async (requestId: string) => {
        const token = localStorage.getItem("token");
        if (!token) {
            toast({
                title: "Login Required",
                description: "Please login to respond to emergency requests",
                variant: "destructive",
            });
            return;
        }

        try {
            const response = await fetch(`http://localhost:5000/api/emergency-requests/${requestId}/respond`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`,
                },
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error);
            }

            toast({
                title: "Thank you! 🙏",
                description: data.message,
            });

            fetchRequests();
        } catch (error: any) {
            toast({
                title: "Error",
                description: error.message || "Failed to respond",
                variant: "destructive",
            });
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case "Critical": return "destructive";
            case "Urgent": return "default";
            case "High": return "secondary";
            default: return "outline";
        }
    };

    const getTimeAgo = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        if (diffMins < 60) return `${diffMins} minutes ago`;
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours} hours ago`;
        return `${Math.floor(diffHours / 24)} days ago`;
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <Header />

            <main className="container py-8">
                <div className="flex items-center gap-3 mb-4">
                    <AlertCircle className="h-10 w-10 text-destructive" />
                    <div>
                        <h1 className="text-4xl font-bold">Emergency Blood Requests</h1>
                        <p className="text-gray-600">Urgent requests that need immediate attention</p>
                    </div>
                </div>

                {loading ? (
                    <div className="text-center py-16">
                        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                        <p>Loading requests...</p>
                    </div>
                ) : requests.length === 0 ? (
                    <div className="text-center py-16 bg-white rounded-xl">
                        <AlertCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold mb-2">No Emergency Requests</h3>
                        <p className="text-gray-500">
                            There are no active emergency requests at the moment.
                        </p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {requests.map((request) => (
                            <Card key={request._id} className="border-l-4 border-l-destructive hover:shadow-lg transition-shadow">
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <CardTitle className="text-4xl font-bold text-primary">
                                            {request.bloodType}
                                        </CardTitle>
                                        <Badge variant={getStatusColor(request.status) as any}>
                                            {request.status}
                                        </Badge>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-gray-500">
                                        <Clock className="h-4 w-4" />
                                        {getTimeAgo(request.createdAt)}
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {request.hospital && (
                                            <div className="flex items-center gap-2 text-sm">
                                                <MapPin className="h-4 w-4 text-primary" />
                                                <span className="font-medium">{request.hospital}</span>
                                            </div>
                                        )}
                                        {request.location && (
                                            <div className="text-sm text-gray-600 ml-6">
                                                {request.location}
                                            </div>
                                        )}
                                        <div className="text-sm">
                                            <span className="font-semibold">Units needed:</span> {request.unitsNeeded}
                                        </div>
                                        {request.contactName && (
                                            <div className="flex items-center gap-2 text-sm">
                                                <User className="h-4 w-4" />
                                                {request.contactName}
                                            </div>
                                        )}
                                        {request.contactPhone && (
                                            <div className="flex items-center gap-2 text-sm">
                                                <Phone className="h-4 w-4" />
                                                {request.contactPhone}
                                            </div>
                                        )}
                                        {request.message && (
                                            <p className="text-sm text-gray-600 italic">"{request.message}"</p>
                                        )}
                                        <div className="text-xs text-gray-500">
                                            {request.responses.length} donor(s) responded
                                        </div>
                                        <Button
                                            className="w-full"
                                            onClick={() => handleRespond(request._id)}
                                        >
                                            Respond to Help
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </main>

            <Footer />
        </div>
    );
};

export default Emergency;
