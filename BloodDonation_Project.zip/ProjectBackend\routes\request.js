const express = require("express");
const router = express.Router();
const Request = require("../models/Request");

router.post("/", async (req, res) => {
  try {
    const { hospital_name, blood_group, units_required, urgency } = req.body;
    const newRequest = new Request({ hospital_name, blood_group, units_required, urgency });
    await newRequest.save();
    res.json({ message: "Blood request created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const requests = await Request.find({ status: "open" });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;