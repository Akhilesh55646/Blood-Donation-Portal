const mongoose = require("mongoose");

const RequestSchema = new mongoose.Schema({
  hospital_name: { type: String, required: true },
  blood_group: { type: String, required: true },
  units_required: { type: Number, required: true },
  urgency: { type: String, enum: ["low", "medium", "high"], default: "medium" },
  status: { type: String, enum: ["open", "fulfilled", "cancelled"], default: "open" },
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Request", RequestSchema);