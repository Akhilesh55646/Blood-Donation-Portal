// fix-port.js
// Automatically find and free port 5000 on Windows

const { exec } = require("child_process");

const PORT = 5000; // agar tumhara project dusre port pe hai to yahan change kar lo

console.log(`🔍 Checking for any process using port ${PORT}...`);

exec(`netstat -ano | findstr :${PORT}`, (err, stdout, stderr) => {
  if (err || !stdout) {
    console.log(`✅ Port ${PORT} is already free.`);
    return;
  }

  const lines = stdout.trim().split("\n");
  const pids = [];

  lines.forEach(line => {
    const parts = line.trim().split(/\s+/);
    const pid = parts[parts.length - 1];
    if (!pids.includes(pid)) pids.push(pid);
  });

  if (pids.length === 0) {
    console.log(`✅ Port ${PORT} is free.`);
    return;
  }

  console.log(`⚠️  Found ${pids.length} process(es) using port ${PORT}: ${pids.join(", ")}`);

  pids.forEach(pid => {
    exec(`taskkill /PID ${pid} /F`, (killErr) => {
      if (killErr) {
        console.log(`❌ Failed to kill PID ${pid}: ${killErr.message}`);
      } else {
        console.log(`🧹 Killed process with PID ${pid}.`);
      }
    });
  });
});
