import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Droplet, MapPin, Phone, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";

interface Donor {
    _id: string;
    name: string;
    bloodGroup: string;
    location: string;
    mobile: string;
    isAvailable: boolean;
}

const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

const FindDonors = () => {
    const { toast } = useToast();
    const [donors, setDonors] = useState<Donor[]>([]);
    const [loading, setLoading] = useState(false);
    const [filters, setFilters] = useState({
        bloodGroup: "",
        location: "",
    });

    const fetchDonors = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.bloodGroup) params.append("bloodGroup", filters.bloodGroup);
            if (filters.location) params.append("location", filters.location);

            const response = await fetch(`http://localhost:5000/api/donors?${params}`);
            const data = await response.json();
            setDonors(data);
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to fetch donors",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchDonors();
    }, []);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        fetchDonors();
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <Header />

            <main className="container py-8">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold mb-4">Find Blood Donors</h1>
                    <p className="text-gray-600 max-w-2xl mx-auto">
                        Search for available blood donors in your area. Contact them directly for urgent needs.
                    </p>
                </div>

                {/* Search Form */}
                <form onSubmit={handleSearch} className="bg-white p-6 rounded-xl shadow-md mb-8">
                    <div className="grid md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-medium mb-2">Blood Group</label>
                            <Select
                                value={filters.bloodGroup}
                                onValueChange={(value) => setFilters({ ...filters, bloodGroup: value })}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select blood group" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="">All Blood Groups</SelectItem>
                                    {bloodGroups.map((bg) => (
                                        <SelectItem key={bg} value={bg}>{bg}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-2">Location</label>
                            <Input
                                placeholder="Enter city or area"
                                value={filters.location}
                                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                            />
                        </div>
                        <div className="flex items-end">
                            <Button type="submit" className="w-full" disabled={loading}>
                                <Search className="mr-2 h-4 w-4" />
                                {loading ? "Searching..." : "Search Donors"}
                            </Button>
                        </div>
                    </div>
                </form>

                {/* Results */}
                {donors.length === 0 ? (
                    <div className="text-center py-16 bg-white rounded-xl">
                        <Droplet className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold mb-2">No Donors Found</h3>
                        <p className="text-gray-500 mb-4">
                            {filters.bloodGroup || filters.location
                                ? "Try adjusting your search criteria"
                                : "Be the first to register as a donor!"}
                        </p>
                        <Link to="/register">
                            <Button>Register as Donor</Button>
                        </Link>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {donors.map((donor) => (
                            <Card key={donor._id} className="hover:shadow-lg transition-shadow">
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <CardTitle className="flex items-center gap-2">
                                            <User className="h-5 w-5 text-primary" />
                                            {donor.name}
                                        </CardTitle>
                                        <Badge className="text-lg px-3 py-1 bg-primary">
                                            {donor.bloodGroup}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {donor.location && (
                                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                                <MapPin className="h-4 w-4" />
                                                {donor.location}
                                            </div>
                                        )}
                                        {donor.mobile && (
                                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                                <Phone className="h-4 w-4" />
                                                {donor.mobile}
                                            </div>
                                        )}
                                        <Badge variant={donor.isAvailable ? "default" : "secondary"}>
                                            {donor.isAvailable ? "Available" : "Not Available"}
                                        </Badge>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </main>

            <Footer />
        </div>
    );
};

export default FindDonors;
