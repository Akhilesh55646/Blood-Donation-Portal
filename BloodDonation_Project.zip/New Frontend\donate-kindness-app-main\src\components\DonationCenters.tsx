import { MapPin, Clock, Star, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

const centers = [
  {
    name: "Central Blood Bank",
    status: "Open",
    rating: 4.8,
    reviews: 156,
    address: "123 Main Street, Downtown",
    distance: "1.2 km away",
    hours: "8:00 AM - 8:00 PM",
    services: ["Whole Blood", "Plasma", "Platelets"],
  },
  {
    name: "Community Health Center",
    status: "Open",
    rating: 4.6,
    reviews: 89,
    address: "456 Oak Avenue, Midtown",
    distance: "2.8 km away",
    hours: "9:00 AM - 6:00 PM",
    services: ["Whole Blood", "Plasma"],
  },
  {
    name: "University Medical Center",
    status: "Open",
    rating: 4.9,
    reviews: 203,
    address: "789 Campus Drive, University District",
    distance: "4.5 km away",
    hours: "7:00 AM - 9:00 PM",
    services: ["Whole Blood", "Plasma", "Platelets", "Research"],
  },
];

export const DonationCenters = () => {
  const handleGetDirections = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, "_blank");
  };

  return (
    <section className="py-16">
      <div className="container">
        <h2 className="text-3xl font-bold mb-4">Find Donation Centers Near You</h2>
        <p className="text-muted-foreground mb-8">
          Locate the nearest donation center and schedule your appointment today.
        </p>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          {centers.map((center, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-xl">{center.name}</CardTitle>
                  <Badge className="bg-green-500">{center.status}</Badge>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">{center.rating}</span>
                  <span className="text-muted-foreground">({center.reviews} reviews)</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-primary mt-0.5" />
                    <div>
                      <p className="font-medium">{center.address}</p>
                      <p className="text-muted-foreground">{center.distance}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-primary" />
                    <span>{center.hours}</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold mb-2">Services:</p>
                    <div className="flex flex-wrap gap-2">
                      {center.services.map((service, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => handleGetDirections(center.address)}
                  >
                    <Navigation className="mr-2 h-4 w-4" />
                    Get Directions
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link to="/centers">
            <Button variant="outline" size="lg">
              View All Centers
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};
