import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { EmergencyRequests } from "@/components/EmergencyRequests";
import { DonationCenters } from "@/components/DonationCenters";
import { BecomeLifeSaver } from "@/components/BecomeLifeSaver";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <EmergencyRequests />
        <DonationCenters />
        <BecomeLifeSaver />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
