import { CheckCircle2, Droplet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";

const eligibilityChecks = [
  "Age 18-65 years old",
  "Weight at least 50kg (110 lbs)",
  "Good general health",
  "No recent travel to high-risk areas",
  "No major surgeries in last 6 months",
];

const bloodTypes = [
  { type: "O-", label: "Universal Donor", demand: "High Demand", color: "destructive" as const },
  { type: "O+", label: "Most Common", demand: "High Demand", color: "destructive" as const },
  { type: "A-", label: "A and AB types", demand: "Medium Demand", color: "default" as const },
  { type: "A+", label: "A and AB positive", demand: "Medium Demand", color: "default" as const },
  { type: "B-", label: "B and AB types", demand: "Medium Demand", color: "default" as const },
  { type: "B+", label: "B and AB positive", demand: "Medium Demand", color: "default" as const },
  { type: "AB-", label: "AB types only", demand: "Low Demand", color: "secondary" as const },
  { type: "AB+", label: "Universal Recipient", demand: "Low Demand", color: "secondary" as const },
];

export const BecomeLifeSaver = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container">
        <h2 className="text-3xl font-bold mb-4 text-center">Become a Life Saver</h2>
        <p className="text-muted-foreground mb-12 text-center max-w-2xl mx-auto">
          Join our community of heroes. Register as a donor and help save lives in your area.
        </p>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Eligibility Check</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-6">
                {eligibilityChecks.map((check, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                    <span className="text-sm">{check}</span>
                  </div>
                ))}
              </div>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg mb-4">
                <p className="font-semibold text-green-800">You're eligible to donate!</p>
                <p className="text-sm text-green-700">Complete your registration to start saving lives.</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/register" className="flex-1">
                  <Button className="w-full">Complete Registration</Button>
                </Link>
                <Link to="/donate" className="flex-1">
                  <Button variant="outline" className="w-full">Register as Donor</Button>
                </Link>
              </div>
              <p className="text-xs text-muted-foreground text-center mt-4">
                Registration takes less than 5 minutes
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Blood Type Compatibility</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {bloodTypes.map((blood, index) => (
                  <div
                    key={index}
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl font-bold text-primary">{blood.type}</span>
                      <Droplet className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-xs text-muted-foreground mb-1">{blood.label}</p>
                    <Badge variant={blood.color} className="text-xs">
                      {blood.demand}
                    </Badge>
                  </div>
                ))}
              </div>
              <div className="p-4 bg-secondary/50 rounded-lg">
                <p className="text-sm font-semibold mb-1">Don't know your blood type?</p>
                <p className="text-xs text-muted-foreground">
                  We'll test it during your first donation at no cost.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
