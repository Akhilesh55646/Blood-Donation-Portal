import { Heart, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary via-accent to-primary py-24">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0djItaDJ2LTJoLTJ6bTAtNGgydjJoLTJ2LTJ6bTAgNGgydjJoLTJ2LTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30"></div>

      <div className="container relative z-10">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="mb-6 text-5xl font-bold text-white md:text-6xl lg:text-7xl">
            Donate Blood, <span className="text-pink-200">Share Life</span>
          </h1>
          <p className="mb-8 text-lg text-white/90 md:text-xl">
            Connect with your community to save lives. Every donation can help up to 3 people.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link to="/donate">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 text-base font-semibold shadow-lg">
                <Heart className="mr-2 h-5 w-5" />
                Donate Now
              </Button>
            </Link>
            <Link to="/find-donors">
              <Button size="lg" variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 text-base font-semibold">
                <Users className="mr-2 h-5 w-5" />
                Find Donors
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <StatCard number="2,547" label="Lives Saved" />
            <StatCard number="1,234" label="Active Donors" />
            <StatCard number="89" label="Donation Centers" />
            <StatCard number="24/7" label="Emergency Support" />
          </div>
        </div>
      </div>
    </section>
  );
};

const StatCard = ({ number, label }: { number: string; label: string }) => (
  <div className="rounded-xl bg-white/10 backdrop-blur-sm p-6 border border-white/20">
    <div className="text-3xl md:text-4xl font-bold text-white mb-1">{number}</div>
    <div className="text-sm text-white/80">{label}</div>
  </div>
);
