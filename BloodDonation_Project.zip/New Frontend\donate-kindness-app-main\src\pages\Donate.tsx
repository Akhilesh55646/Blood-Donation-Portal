import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Heart, Droplet, MapPin, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";

const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

const Donate = () => {
    const navigate = useNavigate();
    const { toast } = useToast();
    const [isLoading, setIsLoading] = useState(false);
    const [formData, setFormData] = useState({
        bloodGroup: "",
        location: "",
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        const token = localStorage.getItem("token");
        if (!token) {
            toast({
                title: "Login Required",
                description: "Please login to register as a donor",
                variant: "destructive",
            });
            navigate("/login");
            return;
        }

        if (!formData.bloodGroup) {
            toast({
                title: "Error",
                description: "Please select your blood group",
                variant: "destructive",
            });
            return;
        }

        setIsLoading(true);

        try {
            const response = await fetch("http://localhost:5000/api/donors", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`,
                },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "Failed to register");
            }

            toast({
                title: "Thank you! ❤️",
                description: "You are now registered as a blood donor!",
            });

            navigate("/");
        } catch (error: any) {
            toast({
                title: "Error",
                description: error.message || "Something went wrong",
                variant: "destructive",
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <Header />

            <main className="container py-8">
                <div className="max-w-2xl mx-auto">
                    <div className="text-center mb-8">
                        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Heart className="h-10 w-10 text-primary" />
                        </div>
                        <h1 className="text-4xl font-bold mb-4">Become a Donor</h1>
                        <p className="text-gray-600">
                            Register as a blood donor and help save lives in your community.
                            Your single donation can save up to 3 lives!
                        </p>
                    </div>

                    <div className="bg-white rounded-2xl shadow-xl p-8">
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <Label className="text-sm font-medium">
                                    Blood Group *
                                </Label>
                                <Select
                                    value={formData.bloodGroup}
                                    onValueChange={(value) => setFormData({ ...formData, bloodGroup: value })}
                                >
                                    <SelectTrigger className="h-12">
                                        <Droplet className="mr-2 h-5 w-5 text-primary" />
                                        <SelectValue placeholder="Select your blood group" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {bloodGroups.map((bg) => (
                                            <SelectItem key={bg} value={bg}>
                                                <span className="font-semibold">{bg}</span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <Label className="text-sm font-medium">
                                    Location
                                </Label>
                                <div className="relative">
                                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                    <Input
                                        placeholder="Enter your city or area"
                                        value={formData.location}
                                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                                        className="pl-10 h-12"
                                    />
                                </div>
                            </div>

                            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                                <h3 className="font-semibold text-green-800 mb-2">Why Donate Blood?</h3>
                                <ul className="text-sm text-green-700 space-y-1">
                                    <li>• One donation can save up to 3 lives</li>
                                    <li>• Blood cannot be manufactured - it can only come from donors</li>
                                    <li>• Someone needs blood every 2 seconds</li>
                                    <li>• It takes only 10-15 minutes to donate</li>
                                </ul>
                            </div>

                            <Button
                                type="submit"
                                disabled={isLoading}
                                className="w-full h-12 text-lg"
                            >
                                {isLoading ? (
                                    <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                ) : (
                                    <>
                                        Register as Donor
                                        <ArrowRight className="ml-2 h-5 w-5" />
                                    </>
                                )}
                            </Button>
                        </form>

                        <p className="text-center text-sm text-gray-500 mt-6">
                            Not logged in?{" "}
                            <Link to="/login" className="text-primary hover:underline">
                                Login first
                            </Link>
                        </p>
                    </div>
                </div>
            </main>

            <Footer />
        </div>
    );
};

export default Donate;
